# VipVideo Android（个人适配版）

原项目：https://github.com/iodefog/VipVideo （MIT License，作者雾颂）。

这是为 Android 创建的**独立原生 Java/WebView 工程**，不是将 macOS Objective-C 代码直接转换为 APK；不含原项目的 VIP 破解接口。

## 功能
- 视频网站入口：B站、腾讯视频、爱奇艺、优酷、芒果TV、央视网。
- 自定义 HTTPS 网页入口（可用于个人 Jellyfin/NAS 网页控制台）。
- 地址栏、前进后退、刷新、外部浏览器打开。
- 收藏、最近访问记录（本地储存）、网页全屏视频。
- 不默认获取存储或通讯录权限；仅使用互联网权限。

注意：网页站点可能禁用 WebView 播放、要求正式会员、在中国地区有访问限制。网站内容、视频版权和 DRM 由来源方负责。建议使用官方客户端观看要求 DRM 的平台视频。本 APP 不绕过付费限制。

## 荣耀 Magic8 构建

### 电脑端（Windows 11）
1. 安装 Android Studio 最新稳定版（包含 Android SDK）。
2. Android Studio -> Open -> 选择 `VipVideo_Android` 文件夹。
3. 等待 Gradle 同步，出现缺失 SDK 时按照 IDE 提示安装 **Android SDK Platform 35** 与 JDK 17（IDE 一般自带）。
4. 菜单 `Build > Build APK(s)`，选择 debug 构建。文件位置：`app/build/outputs/apk/debug/app-debug.apk`。
5. USB 复制 APK 到手机；荣耀 Magic8 点击安装，按照系统提示允许此来源安装。不要关闭系统安全检查。

### 命令行（电脑安装 Gradle 8.9，JDK17 和 Android SDK 后）
```
gradle assembleDebug
```
本仓库不包含 Gradle Wrapper JAR 文件，因此建议 Android Studio 先同步或使用本地 Gradle。

## 局限
- 尚未在当前环境运行 `gradle assembleDebug`，没有已验证 APK。
- 不是完整影视搜索/点播客户端；网页搜索依赖各视频平台。
- Jellyfin 可配置网页导航，但还未集成 Jellyfin 原生 API。
- 仅 HTTPS，局域网 HTTP NAS 需部署 HTTPS 代理后访问。

## 不在电脑安装 Android Studio：GitHub Actions 云端编译
将本工程目录的所有文件（包括隐藏的 `.github` 目录）上传到**你自己控制的 GitHub 仓库**，打开 `Actions -> Build Android APK -> Run workflow`，完成后下载 `VipVideoAndroid-debug-apk` 构建产物，解压得到 `app-debug.apk`。如无运行按钮，先检查 workflow 文件是否已推送到仓库默认分支，并确认 Actions 已启用。

此方法需要你自己的 GitHub 仓库和可用的 GitHub Actions 配额；APK 为调试签名，仅供个人测试。
