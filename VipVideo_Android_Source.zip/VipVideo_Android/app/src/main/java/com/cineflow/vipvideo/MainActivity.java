package com.cineflow.vipvideo;

import android.app.*;
import android.os.*;
import android.content.*;
import android.graphics.Color;
import android.graphics.Bitmap;
import android.net.Uri;
import android.view.*;
import android.view.inputmethod.InputMethodManager;
import android.webkit.*;
import android.widget.*;
import org.json.*;
import java.util.*;

/** Original Android implementation inspired by the navigation features of iodefog/VipVideo (MIT). */
public final class MainActivity extends Activity {
    private static final String HOME = "https://www.bilibili.com/";
    private static final String PREF = "vipvideo_android_data";
    private final LinkedHashMap<String,String> portals = new LinkedHashMap<>();
    private final ArrayList<String> bookmarks = new ArrayList<>();
    private final ArrayList<String> history = new ArrayList<>();
    private WebView browser;
    private EditText address;
    private ProgressBar progress;
    private View fullscreenView;
    private WebChromeClient.CustomViewCallback fullscreenCallback;
    private FrameLayout root, fullscreen;
    private android.webkit.ValueCallback<Uri[]> uploadCallback;
    private static final int FILE_REQUEST = 2026;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(Color.rgb(16, 19, 27));
        getWindow().setNavigationBarColor(Color.rgb(16, 19, 27));
        portals.put("哔哩哔哩", "https://www.bilibili.com/");
        portals.put("腾讯视频", "https://v.qq.com/");
        portals.put("爱奇艺", "https://www.iqiyi.com/");
        portals.put("优酷", "https://www.youku.com/");
        portals.put("芒果TV", "https://www.mgtv.com/");
        portals.put("央视网", "https://tv.cctv.com/");
        readSaved();
        buildUi();
        String last = getPreferences(MODE_PRIVATE).getString("last", HOME);
        navigate(last);
    }
    private int dp(float n){return (int)(getResources().getDisplayMetrics().density*n + .5f);}
    private TextView button(String text, LinearLayout row, Runnable task){
        TextView t = new TextView(this); t.setText(text); t.setTextColor(Color.WHITE);
        t.setTextSize(13); t.setGravity(Gravity.CENTER); t.setPadding(dp(10),dp(12),dp(10),dp(12));
        t.setBackgroundColor(Color.rgb(31, 38, 51));
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(0,dp(47),1f);p.setMargins(dp(2),0,dp(2),0);
        row.addView(t,p);t.setOnClickListener(v->task.run());return t;
    }
    private void buildUi(){
        root = new FrameLayout(this);
        LinearLayout body = new LinearLayout(this);body.setOrientation(LinearLayout.VERTICAL);
        body.setBackgroundColor(Color.rgb(16,19,27));root.addView(body);
        LinearLayout top = new LinearLayout(this);top.setPadding(dp(4),dp(7),dp(4),dp(7));
        body.addView(top);
        address=new EditText(this);address.setSingleLine(true);address.setTextSize(13);
        address.setTextColor(Color.WHITE);address.setHintTextColor(Color.LTGRAY);address.setHint("输入合法 HTTPS 网址");
        address.setBackgroundTintList(android.content.res.ColorStateList.valueOf(Color.rgb(114, 137, 170)));
        top.addView(address,new LinearLayout.LayoutParams(0,dp(45),1f));
        TextView go=new TextView(this);go.setText("打开");go.setTextColor(Color.WHITE);go.setGravity(Gravity.CENTER);
        go.setPadding(dp(12),0,dp(12),0);top.addView(go);go.setOnClickListener(v->navigate(address.getText().toString()));
        address.setOnEditorActionListener((v,id,event)->{navigate(address.getText().toString());return true;});
        progress=new ProgressBar(this,null,android.R.attr.progressBarStyleHorizontal);
        progress.setMax(100);progress.setVisibility(View.GONE);body.addView(progress,new LinearLayout.LayoutParams(-1,dp(3)));
        browser=new WebView(this);
        browser.setBackgroundColor(Color.rgb(16,19,27));
        WebSettings cfg=browser.getSettings();cfg.setJavaScriptEnabled(true);cfg.setDomStorageEnabled(true);
        cfg.setMediaPlaybackRequiresUserGesture(true);cfg.setAllowFileAccess(false);
        cfg.setAllowContentAccess(true);cfg.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        cfg.setSupportMultipleWindows(false);cfg.setBuiltInZoomControls(false);
        browser.setWebViewClient(new WebViewClient(){
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest req){
                Uri uri=req.getUrl();String scheme=uri.getScheme();
                if("https".equalsIgnoreCase(scheme)) return false;
                if("http".equalsIgnoreCase(scheme)){toast("仅允许 HTTPS 站点");return true;}
                // Open external app links through Android; never expose local/file URLs to WebView.
                if("intent".equalsIgnoreCase(scheme)||"market".equalsIgnoreCase(scheme)){
                    try {startActivity(new Intent(Intent.ACTION_VIEW,uri));}catch(Exception e){toast("无法打开外部应用");}
                }
                return true;
            }
            @Override public void onPageStarted(WebView v,String u,Bitmap b){address.setText(u);progress.setVisibility(View.VISIBLE);}
            @Override public void onPageFinished(WebView v,String u){if(u!=null&&u.startsWith("https://")){recordHistory(u);getPreferences(MODE_PRIVATE).edit().putString("last",u).apply();}}
            @Override public void onReceivedError(WebView v,WebResourceRequest r,WebResourceError e){if(r.isForMainFrame()) toast("页面加载失败，请检查网络或网址");}
        });
        browser.setWebChromeClient(new WebChromeClient(){
            @Override public void onProgressChanged(WebView w,int p){progress.setProgress(p);if(p==100)progress.setVisibility(View.GONE);}
            @Override public void onShowCustomView(View view,CustomViewCallback cb){
                if(fullscreenView!=null){cb.onCustomViewHidden();return;}
                fullscreenView=view;fullscreenCallback=cb;
                fullscreen=new FrameLayout(MainActivity.this);fullscreen.setBackgroundColor(Color.BLACK);
                fullscreen.addView(view,new FrameLayout.LayoutParams(-1,-1));root.addView(fullscreen,new FrameLayout.LayoutParams(-1,-1));
                getWindow().getDecorView().setSystemUiVisibility(5894 | View.SYSTEM_UI_FLAG_FULLSCREEN);
            }
            @Override public void onHideCustomView(){closeFullscreen();}
            @Override public boolean onShowFileChooser(WebView w,ValueCallback<Uri[]> callback,FileChooserParams params){
                if(uploadCallback!=null)uploadCallback.onReceiveValue(null);
                uploadCallback=callback;
                try{startActivityForResult(params.createIntent(),FILE_REQUEST);}catch(Exception e){uploadCallback=null;callback.onReceiveValue(null);return false;}
                return true;
            }
        });
        body.addView(browser,new LinearLayout.LayoutParams(-1,0,1f));
        LinearLayout nav=new LinearLayout(this);nav.setPadding(dp(2),dp(5),dp(2),dp(6));body.addView(nav);
        button("首页",nav,()->showPortals());
        button("后退",nav,()->{if(browser.canGoBack())browser.goBack();});
        button("前进",nav,()->{if(browser.canGoForward())browser.goForward();});
        button("收藏",nav,()->showBookmarks());
        button("记录",nav,()->showHistory());
        LinearLayout nav2=new LinearLayout(this);nav2.setPadding(dp(2),0,dp(2),dp(7));body.addView(nav2);
        button("刷新",nav2,()->browser.reload());
        button("收藏本页",nav2,()->{String u=browser.getUrl();if(u!=null&&u.startsWith("https://")&&!bookmarks.contains(u)){bookmarks.add(0,u);save();toast("收藏成功");}});
        button("新增入口",nav2,()->addPortalDialog());
        button("外部浏览器",nav2,()->{String u=browser.getUrl();if(u!=null)startActivity(new Intent(Intent.ACTION_VIEW,Uri.parse(u)));});
        setContentView(root);
    }
    private void navigate(String input){
        if(input==null)return;String url=input.trim();
        if(!url.contains("://"))url="https://"+url;
        Uri u=Uri.parse(url);
        if(!"https".equalsIgnoreCase(u.getScheme())||u.getHost()==null||u.getHost().isEmpty()){
            toast("仅支持有效的 HTTPS 地址");return;
        }
        address.setText(url);browser.loadUrl(url);address.clearFocus();
        ((InputMethodManager)getSystemService(INPUT_METHOD_SERVICE)).hideSoftInputFromWindow(address.getWindowToken(),0);
    }
    private void showPortals(){
        ArrayList<String> labels=new ArrayList<>(portals.keySet());
        new AlertDialog.Builder(this).setTitle("影视平台（需遵守各平台会员及版权规则）")
          .setItems(labels.toArray(new String[0]),(d,index)->navigate(portals.get(labels.get(index))))
          .setNegativeButton("关闭",null).show();
    }
    private void addPortalDialog(){
        LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.VERTICAL);l.setPadding(dp(18),dp(5),dp(18),0);
        EditText name=new EditText(this);name.setHint("名称，例如家庭 Jellyfin");l.addView(name);
        EditText url=new EditText(this);url.setHint("https:// 开头的完整网址");l.addView(url);
        new AlertDialog.Builder(this).setTitle("新增网站入口").setView(l)
          .setPositiveButton("保存",(d,w)->{
              String n=name.getText().toString().trim();String u=url.getText().toString().trim();
              Uri parsed=Uri.parse(u);
              if(n.isEmpty()||!"https".equalsIgnoreCase(parsed.getScheme())||parsed.getHost()==null){toast("名称或 HTTPS URL 无效");return;}
              portals.put(n,u);save();toast("入口已保存");
          }).setNegativeButton("取消",null).show();
    }
    private void showBookmarks(){showUrlList("我的收藏",bookmarks,true);}
    private void showHistory(){showUrlList("浏览历史",history,false);}
    private void showUrlList(String title,ArrayList<String> arr,boolean bookmark){
        if(arr.isEmpty()){toast("暂无记录");return;}
        String[] items=arr.toArray(new String[0]);
        new AlertDialog.Builder(this).setTitle(title).setItems(items,(d,i)->navigate(items[i]))
          .setNeutralButton(bookmark?"清空收藏":"清空历史",(d,i)->{
              new AlertDialog.Builder(this).setTitle("确认清空？").setPositiveButton("清空",(dd,ii)->{arr.clear();save();})
                .setNegativeButton("取消",null).show();
          }).setNegativeButton("关闭",null).show();
    }
    private void recordHistory(String url){history.remove(url);history.add(0,url);while(history.size()>100)history.remove(history.size()-1);save();}
    private void readSaved(){
        try{
            JSONObject o=new JSONObject(getSharedPreferences(PREF,MODE_PRIVATE).getString("state","{}"));
            JSONObject p=o.optJSONObject("portals");if(p!=null){Iterator<String> it=p.keys();while(it.hasNext()){String n=it.next();String url=p.optString(n);if(url.startsWith("https://"))portals.put(n,url);}}
            JSONArray b=o.optJSONArray("bookmarks");if(b!=null)for(int i=0;i<b.length();i++)bookmarks.add(b.getString(i));
            JSONArray h=o.optJSONArray("history");if(h!=null)for(int i=0;i<h.length();i++)history.add(h.getString(i));
        }catch(Exception ignored){}
    }
    private void save(){
        try{
            JSONObject o=new JSONObject(),p=new JSONObject();for(Map.Entry<String,String> e:portals.entrySet())p.put(e.getKey(),e.getValue());
            o.put("portals",p);o.put("bookmarks",new JSONArray(bookmarks));o.put("history",new JSONArray(history));
            getSharedPreferences(PREF,MODE_PRIVATE).edit().putString("state",o.toString()).apply();
        }catch(JSONException ignored){}
    }
    private void closeFullscreen(){
        if(fullscreenView==null)return;
        root.removeView(fullscreen);fullscreen=null;fullscreenView=null;
        if(fullscreenCallback!=null){fullscreenCallback.onCustomViewHidden();fullscreenCallback=null;}
        getWindow().getDecorView().setSystemUiVisibility(0);
    }
    private void toast(String s){Toast.makeText(this,s,Toast.LENGTH_SHORT).show();}
    @Override public void onBackPressed(){if(fullscreenView!=null)closeFullscreen();else if(browser.canGoBack())browser.goBack();else super.onBackPressed();}
    @Override protected void onActivityResult(int request,int result,Intent data){
        super.onActivityResult(request,result,data);
        if(request==FILE_REQUEST&&uploadCallback!=null){
            Uri[] resultUris=WebChromeClient.FileChooserParams.parseResult(result,data);
            uploadCallback.onReceiveValue(resultUris);uploadCallback=null;
        }
    }
    @Override protected void onDestroy(){closeFullscreen();if(browser!=null){browser.stopLoading();browser.destroy();}super.onDestroy();}
}
